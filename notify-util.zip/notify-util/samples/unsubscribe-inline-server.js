import Hapi from '@hapi/hapi'
import { verifyUnsubscribeToken } from '../index.js'

// Demo secret ONLY for samples; use env var in real apps
const SECRET = process.env.UNSUBSCRIBE_TOKEN_SECRET || 'test-secret'

async function start() {
  const server = Hapi.server({ port: 4002, host: '0.0.0.0' })

  // Inline implementation of GET /unsubscribe without helper modules
  server.route({
    method: 'GET',
    path: '/unsubscribe',
    handler: async (request, h) => {
      const { sid, token } = request.query
      try {
        if (!sid || !token) {
          throw new Error('Missing sid or token')
        }

        const payload = verifyUnsubscribeToken(token, SECRET)
        if (payload.sid !== sid) {
          throw new Error('Token/sid mismatch')
        }

        // TODO: Persist the unsubscribe (DB/API). Channel can be resolved
        // from your subscription record associated with sid.
        const result = { sid, channel: 'unknown' }

        return h.response({ ok: true, sid, unsubscribed: true, meta: { iat: payload.iat, exp: payload.exp }, result }).code(200)
      } catch (err) {
        return h.response({ ok: false, error: err?.message || 'Unsubscribe failed' }).code(400)
      }
    }
  })

  await server.start()
  console.log(`Inline sample server running at ${server.info.uri}`)
  console.log('Try: GET /unsubscribe?sid=sub_12345&token=<signed-token>')
}

start().catch((err) => {
  console.error('Failed to start inline sample server:', err)
  process.exit(1)
})
