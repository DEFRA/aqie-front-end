import Hapi from '@hapi/hapi'
import { registerUnsubscribeRoutes } from './controllers/unsubscribe-routes.js'
import { generateUnsubscribeToken } from '../index.js'

const SECRET = process.env.UNSUBSCRIBE_TOKEN_SECRET || 'test-secret'
const SUB_ID = 'sub_12345'

async function main() {
  const server = Hapi.server({ port: 4001, host: '0.0.0.0' })

  const markUnsubscribed = async (sid, payload) => {
    // Replace with persistence or API call in real usage
    return { sid, channel: 'unknown' }
  }

  await registerUnsubscribeRoutes(server, { secret: SECRET, markUnsubscribed })
  await server.start()

  const token = generateUnsubscribeToken(SUB_ID, SECRET, 60 * 60)
  const sampleUrl = `${server.info.uri}/unsubscribe?sid=${encodeURIComponent(SUB_ID)}&token=${encodeURIComponent(token)}`

  console.log(`Sample server running at ${server.info.uri}`)
  console.log('Try GET:', sampleUrl)
}

main().catch((err) => {
  console.error('Failed to start unsubscribe routes sample:', err)
  process.exit(1)
})
