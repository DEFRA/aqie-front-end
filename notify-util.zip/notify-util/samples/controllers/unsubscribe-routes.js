import { createUnsubscribeHandler } from './unsubscribe-controller.js'

/**
 * Register a minimal GET /unsubscribe route.
 *
 * Query params:
 * - sid: subscription id
 * - token: signed unsubscribe token
 *
 * @param {import('@hapi/hapi').Server} server
 * @param {{ secret: string, markUnsubscribed?: (sid: string, payload: object) => Promise<object> }} options
 */
export async function registerUnsubscribeRoutes(server, { secret, markUnsubscribed } = {}) {
  const handler = createUnsubscribeHandler({ secret, markUnsubscribed })

  server.route({
    method: 'GET',
    path: '/unsubscribe',
    handler: async (request, h) => {
      const { sid, token } = request.query
      try {
        const result = await handler(sid, token)
        return h.response(result).code(200)
      } catch (err) {
        return h
          .response({ ok: false, error: err?.message || 'Unsubscribe failed' })
          .code(400)
      }
    }
  })
}

export default { registerUnsubscribeRoutes }
