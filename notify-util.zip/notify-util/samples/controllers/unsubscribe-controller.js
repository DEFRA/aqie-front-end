import { verifyUnsubscribeToken } from '../../index.js'

/**
 * Minimal unsubscribe handler.
 *
 * Validates the token, checks it matches the provided subscription id,
 * and invokes the supplied `markUnsubscribed` callback.
 *
 * Errors are thrown for invalid inputs; callers should catch and respond.
 *
 * @param {object} options
 * @param {string} options.secret - HMAC secret used to verify tokens
 * @param {(sid: string, payload: object) => Promise<object>} options.markUnsubscribed - App callback to persist the unsubscribe
 * @returns {(sid: string, token: string) => Promise<object>} handler
 */
export function createUnsubscribeHandler({ secret, markUnsubscribed = async () => ({}) } = {}) {
  if (!secret) throw new Error('secret is required')

  return async function handleUnsubscribe(sid, token) {
    if (!sid || !token) throw new Error('Missing sid or token')

    // Verify token and decode payload
    const payload = verifyUnsubscribeToken(token, secret)

    // Basic guard: token must carry the same subscription id
    if (payload.sid !== sid) throw new Error('Token/sid mismatch')

    // Persist unsubscribe in your system (DB/API). The callback can
    // determine the channel (sms/email) based on the subscription record.
    const result = await markUnsubscribed(sid, payload)

    return {
      ok: true,
      sid,
      unsubscribed: true,
      meta: { iat: payload.iat, exp: payload.exp },
      result
    }
  }
}

export default { createUnsubscribeHandler }
