import Hapi from '@hapi/hapi'
import { registerUnsubscribeRoutes } from './controllers/unsubscribe-routes.js'

// Demo secret ONLY for samples; use env var in real apps
const SECRET = process.env.UNSUBSCRIBE_TOKEN_SECRET || 'test-secret'

async function start() {
  const server = Hapi.server({ port: 4000, host: '0.0.0.0' })

  // In a real app, markUnsubscribed should persist to DB or call an API.
  const markUnsubscribed = async (sid, payload) => {
    console.log('[Unsubscribe] Persisting unsubscribe for', { sid, payload })
    // Return any additional info for client confirmation
    return { sid, channel: 'unknown' }
  }

  await registerUnsubscribeRoutes(server, { secret: SECRET, markUnsubscribed })

  await server.start()
  console.log(`Sample server running at ${server.info.uri}`)
  console.log('Try: GET /unsubscribe?sid=sub_12345&token=<signed-token>')
}

start().catch((err) => {
  console.error('Failed to start sample server:', err)
  process.exit(1)
})
