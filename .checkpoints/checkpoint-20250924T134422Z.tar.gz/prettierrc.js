export default {
  tabWidth: 2,
  semi: false,
  singleQuote: true,
  trailingComma: 'none'
}
