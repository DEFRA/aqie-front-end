import { secureContext } from './secure-context.js'

export { secureContext }
