export const BASE_URL = ''
export const REDIRECT_STATUS_CODE = 301
