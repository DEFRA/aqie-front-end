import { config } from './index.js'

describe('Config', () => {
  it('should load configuration correctly', () => {
    expect(config).toBeDefined()
    // Add more tests for configuration behavior
  })
})
