const govukRebrand = true

export { govukRebrand }
