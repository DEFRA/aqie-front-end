export { default as assign } from 'lodash/assign.js'
