export const COOKIE_BANNER_SELECTOR = '[data-module="govuk-cookie-banner"]'
export const COOKIES_PAGE_SELECTOR = '[data-module="app-cookies-page"]'